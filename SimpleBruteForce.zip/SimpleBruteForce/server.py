from flask import Flask, request, jsonify, send_from_directory
import json
import os

app = Flask(__name__)

# File to store user data
USER_DATA_FILE = 'users.json'

# Initialize users data
def initialize_users():
    if not os.path.exists(USER_DATA_FILE):
        with open(USER_DATA_FILE, 'w') as f:
            json.dump([], f)
    
    try:
        with open(USER_DATA_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

# Save users to file
def save_users(users):
    with open(USER_DATA_FILE, 'w') as f:
        json.dump(users, f)

# Serve the HTML file
@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

# Login endpoint
@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')
    
    if not username or not password:
        return jsonify({"success": False, "message": "Username and password required"})
    
    users = initialize_users()
    
    # Check credentials
    user = next((u for u in users if u['username'] == username and u['password'] == password), None)
    
    if user:
        return jsonify({"success": True, "message": "Login successful!"})
    else:
        return jsonify({"success": False, "message": "Invalid username or password"})

# Register endpoint
@app.route('/register', methods=['POST'])
def register():
    username = request.form.get('new-username')
    password = request.form.get('new-password')
    confirm_password = request.form.get('confirm-password')
    
    if not username or not password or not confirm_password:
        return jsonify({"success": False, "message": "All fields are required"})
    
    if password != confirm_password:
        return jsonify({"success": False, "message": "Passwords do not match"})
    
    users = initialize_users()
    
    # Check if username already exists
    if any(user['username'] == username for user in users):
        return jsonify({"success": False, "message": "Username already exists"})
    
    # Add new user
    users.append({"username": username, "password": password})
    save_users(users)
    
    return jsonify({"success": True, "message": "Registration successful!"})

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8000, debug=True)