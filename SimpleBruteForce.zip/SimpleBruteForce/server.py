from flask import Flask, request, jsonify, send_from_directory
import json
import os

app = Flask(__name__)           # Create a new application

USER_DATA_FILE = 'users.json'   # File to store found users and passwords

# Initialize a file with static information
def initialize_users():
    # If there is no file with users, create it
    if not os.path.exists(USER_DATA_FILE):
        with open(USER_DATA_FILE, 'w') as f:
            json.dump([], f)
    # If the password is already found, return it
    try:
        with open(USER_DATA_FILE, 'r') as f:
            return json.load(f)
    # If not, pass
    except:
        return []

# Save users information
def save_users(users):
    with open(USER_DATA_FILE, 'w') as f:
        json.dump(users, f)

# Set the home directory
@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

# Set the login directory
@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username')         # Use the inputed username
    password = request.form.get('password')         # Use the inputed password
    
    # If not valid username or password
    if not username or not password:
        return jsonify({"success": False, "message": "Username and password required"})
    
    # Initialize users
    users = initialize_users()
    
    # Find the user
    user = next((u for u in users if u['username'] == username and u['password'] == password), None)
    
    # Grant acces if the user is valid
    if user:
        return jsonify({"success": True, "message": "Login successful!"})
    else:               # Else invalid login
        return jsonify({"success": False, "message": "Invalid username or password"})

# Set the register directory
@app.route('/register', methods=['POST'])
def register():
    username = request.form.get('new-username')                 # Create a new username
    password = request.form.get('new-password')                 # Create new password
    confirm_password = request.form.get('confirm-password')     # Confirmation password
    
    # If not valid username of password
    if not username or not password or not confirm_password:    
        return jsonify({"success": False, "message": "All fields are required"})
    
    # If confirmation password not valid
    if password != confirm_password:
        return jsonify({"success": False, "message": "Passwords do not match"})
    
    # Initialize users
    users = initialize_users()
    # Verify if the user exists
    if any(user['username'] == username for user in users):
        return jsonify({"success": False, "message": "Username already exists"})
    # Add new username
    users.append({"username": username, "password": password})
    # Save the user
    save_users(users)
    return jsonify({"success": True, "message": "Registration successful!"})

# Run the Flask server on localhost, port 8000
if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8000, debug=True)